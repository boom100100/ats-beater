# ATS Beater

## Description
Appends the job description of the current webpage to your resume.

## Package
MacOs has weird compression issues when making .zip files, so use the following command for creating .zip to upload to Google:

    zip -r .chrome_extensions_assets/ats_beater0.0.v.zip *

Be sure to update the version number for the output.
